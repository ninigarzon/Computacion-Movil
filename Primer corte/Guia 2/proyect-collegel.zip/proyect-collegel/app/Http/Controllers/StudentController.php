<?php

namespace App\Http\Controllers;

use App\Http\Requests\StudentRequest;
use App\Models\Student;

class StudentController extends Controller
{
    public function create(StudentRequest $request)
    {
        $student = new Student($request->all());
        $student->save();
        return $student;
    }

    public function all()
    {
        return Student::all();
    }

    public function update(string $idStudent, StudentRequest $request)
    {
        Student::findOrFail($idStudent)->update($request->all());
        return Student::findOrFail($idStudent);
    }

    public function delete(string $idStudent)
    {
        Student::findOrFail($idStudent)->delete();
        return 'OK';
    }
}
